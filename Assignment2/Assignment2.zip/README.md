# Code for Assignment 2 for the course OpenCV-102 Computer Vision 1: Introduction (C++) from OpenCV.org

Using open CV for image annotation
 
see [instructions](./instructions) for task description